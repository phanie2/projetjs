-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le :  jeu. 28 mars 2019 à 19:02
-- Version du serveur :  10.1.28-MariaDB
-- Version de PHP :  5.6.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `village`
--

-- --------------------------------------------------------

--
-- Structure de la table `clients`
--

CREATE TABLE `clients` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `pasword` varchar(100) NOT NULL,
  `adresse` varchar(255) NOT NULL,
  `telephone` varchar(255) NOT NULL,
  `ville` varchar(255) NOT NULL,
  `avis` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `clients`
--

INSERT INTO `clients` (`id`, `email`, `pasword`, `adresse`, `telephone`, `ville`, `avis`) VALUES
(1, 'hermanndsafe@gmail.com', 'cc', 'zaghedz', '11111111', 'aef', ''),
(2, 'hermanndsafe@gmail.com', '', 'zaghedz', '11111111', 'aef', ''),
(3, 'utilisateur@nan.ci', 'azer', 'zaghedz', '11111111', 'aef', ''),
(4, 'epiphaniemilena@gmail.com', 'epi', 'cocody', '11111111', 'abidjan', ''),
(5, 'adelphesfa@gmail.com', 'wxc', 'cocody', '11111111', 'abidjan', ''),
(6, 'adelphesfa@gmail.com', 'wxc', 'cocody', '11111111', 'abidjan', ''),
(7, 'adelphesfa@gmail.com', 'wxc', 'cocody', '11111111', 'abidjan', ''),
(8, 'adelphesfa@gmail.com', 'wxc', 'cocody', '11111111', 'abidjan', ''),
(9, 'ramseykoffi080@gmail.com', 'czz', 'cocody', '11111111', 'aef', ''),
(10, 'micodium3@gmail.com', 'rhdx', 'ey\'gsw', '11111111', 'abidjan', ''),
(11, 'micodium3@gmail.com', '', 'ey\'gsw', '11111111', 'abidjan', ''),
(12, 'ramseykoffi080@gmail.com', 'czz', 'cocody', '11111111', 'aef', ''),
(13, 'adelphesfa@gmail.com', 'wxc', 'cocody', '11111111', 'abidjan', ''),
(14, 'ramseykoffi080@gmail.com', 'dgsw', 'hd', 'h', 'hf', ''),
(15, 'hermanndsafe@gmail.com', 'rtu', 't', 'tu', 't', ''),
(16, 'hermanndsafe@gmail.com', '`ù', 'zaghedz', '11111111', 'aef', ''),
(17, 'hermanndsafe@gmail.com', 'rjtdxvgj', 'tgjgvt', 'tgvj', 'tgvju', ''),
(18, 'hermanndsafe@gmail.com', '', 'tgjgvt', 'tgvj', 'tgvju', ''),
(19, 'hermanndsafe@gmail.com', '', 'tgjgvt', 'tgvj', 'tgvju', ' qgwdfhfhr'),
(20, 'hermanndsafe@gmail.com', 'qzey', 'qrz', '11111111', 'sxzry', ' cest trop bien'),
(21, 'micodium3@gmail.com', '\"rzaft', 'ey\'gsw', 'QDE', 'abidjan', ' J\'AI AIMÉ OH!!!'),
(22, 'hermanndsafe@gmail.com', 'edy', 'r', '11111111', 'rfu', ' eyxtdu'),
(23, 'micodium3@gmail.com', 'zqegq', 'ey\'gsw', '11111111', 'zey', ' ta bien fais'),
(24, 'micodium3@gmail.com', 'zqegq', 'ey\'gsw', '11111111', 'zey', ' ta bien fais'),
(25, 'micodium3@gmail.com', 'zqegq', 'ey\'gsw', '11111111', 'zey', ' ta bien fais'),
(26, 'hermanndsafe@gmail.com', '<qfss?sg', 'ey\'gsw', '11111111', 'abidjan', ' jai mangé'),
(27, 'hermanndsafe@gmail.com', '<dvgf', 'zaghedz', 'gz', 'abidjan', ' lato'),
(28, 'hermanndsafe@gmail.com', 'cfg', 'f', '11111111', 'f', ' fgjnv'),
(29, 'hermanndsafe@gmail.com', 'zs', 'ey\'gsw', '11111111', 'abidjan', ' ,v< bvh'),
(30, 'hermanndsafe@gmail.com', '<qdv', 'cocody', '11111111', 'abidjan', ' njffv'),
(31, 'hermanndsafe@gmail.com', '', 'cocody', '11111111', 'abidjan', ' njffv'),
(32, 'micodium3@gmail.com', 'l:hj;vj kn', 'cocody', '11111111', 'jty', ' lgykyfgu'),
(33, 'hermanndsafe@gmail.com', 'lul', 'cocody', '11111111', 'abidjan', ' bvwdfwnfwh'),
(34, 'hermanndsafe@gmail.com', 'lul', 'cocody', '11111111', 'abidjan', 'AZERTY'),
(35, 'hermanndsafe@gmail.com', 'df', 'fd', 'n', 'fbhgn', ' fvmh:l'),
(36, 'hermanndsafe@gmail.com', 'd', 'cocody', '11111111', 'abidjan', ' <xdsb'),
(37, '', 'qsgs', 'cocody', '11111111', 'abidjan', ' sdgfc'),
(38, 'hermanndsafe@gmail.com', 'rftf', 'cocody', '11111111', 'abidjan', ' fgdxmijgh'),
(39, 'hermanndsafe@gmail.com', 'eg', 'zaghedz', '11111111', 'abidjan', ' hrsts');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
