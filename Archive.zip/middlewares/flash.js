
module.exports = function (req,res,next){

if(req.session.flash){
  Res.locals.flash = req.session.flash
  req.session.flash = undefined



}





  res.flash = function(type,content){
      if (req.session.flash === undefined)
{ req. session.flash = {}
}  
req.session.flash[type] = content
} 
next()

}
