$(document).ready(
	function(){

		$("#Modal").on("click",function () {
			$("#myModal").slideToggle();
			// body...
		})

		$("#Modal1").on("click",function () {
			$("#myModal1").slideToggle();
			// body...
		})
	console.log('tout va')
	


	}
	
);
