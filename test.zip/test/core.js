
var connection= require('./connect');
var mysql = require('promise-mysql');
var express = require('express');
var twig = require('twig');
var express = require('express');
var mysql = require('mysql');


var app = express()
app.use(express.static('views'))
var bodyParser = require('body-parser');
var session = session = require('express-session')

//motreur de template
app.set('view engine', 'twig')

//middleware
app.use(express.static('views'))
app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())

app.use(session({
    secret: ' clavier ',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false }
}));


//app.use(require('./middlewares/flash.js'))




//mysql.createConnection({
// host: 'localhost',
// user: 'root',
// password: '',
// database: 'village'
//}).then(function(db){
// do stuff with conn
// console.log("connection établit");

app.get('/',function(req,res){
    res.render('index 2.twig')
    })
    
app.get('/produit',function(req,res){
        res.render('produit.twig')
        })


app.get('/jus',function(req,res){
    res.render('jus.twig')
  })     

app.get('/plat', function (req, res) {
    res.render('plat.twig')
})



app.get('/inscription', function (req, res) {
    res.render('inscription.twig')
})

app.post('/inscription',(req,res) => {

    var email = req.body.email
    var pwd = req.body.password 
    var adress = req.body.adresse
    var tel = req.body.tel
    var city = req.body.city
    var avis = req.body.avis

    
    
    if( (email == undefined || email == '') && ( tel == undefined ||tel== '') && ( city == undefined || city == '' ) && (adress == undefined || adress == '') && (pwd == undefined || pwd == '') && (avis == undefined || avis == '')){
        console.log("j' ai une erreur")

    }else {

        connection.query('INSERT INTO clients SET email = ?, pasword = ?, adresse = ?, telephone = ?, ville = ?, avis = ?',[email, pwd,adress,tel,city,avis] ,(err,result) => {
        if (err) throw err
      
        console.log(result)
        })
    res.render('inscription')
    }	

console.log('reussi')
} )
app.get('/panier',(req,res) =>{

    connection.query("SELECT email, avis FROM clients ORDER BY id DESC Limit 10", function (err, result, fields) {
        if (err) throw err;
        console.log(result);
       res.render('panier',{result})
      });
    } )



app.listen(3000, ()=>{
    console.log("ecoute sur 3000")
})
