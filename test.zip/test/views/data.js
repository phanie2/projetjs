 $(document).ready(function(){


var objet1= {
id : 1,
nom:"foutou",

description : "du foutou à la banane : met ivoirien fait à base de banane plantain",
img : "images/foutou.JPG"

};
var objet2 ={
id : 2,
nom:"placali",

description : "du placali  : met ivoirien fait à base de manioc",
img : "images/placali.jpg"

};
var objet3 ={
id : 3,
nom:"foufou",

description : "du foufou : met ivoirien fait à base de banane plantain et d huile de palme",
img : "images/foufou.jpg"

};

var objet4 = {
id : 4,
nom:"poisson braisee",

description : "du poisson braisé",
img : "images/braisé.jpg"

};

var objet5= {
id : 5,
nom:"garba",

description : "garba: semoule de manioc acoompagné de poisson thon frit",
img : "images/garba.jpg"

};
var objet6 ={
id : 6,
nom:"riz sauce graine",

description : "du placali  : met ivoirien fait à base de semoule de manioc",
img : "images/riz.jpg"

};
var objet7 ={
id :7 ,
nom:"tchep",

description : "met senegalais ",
img : "images/tchep.jpg"

};

var objet8 = {
id : 8,
nom:"attieke poisson",

description : " de l'attiéké et du poisson",
img : "images/attieke.png"

};
var data=[objet1,objet2,objet3,objet4,objet5,objet6,objet7,objet8] ;
console.log(data);

for (var i = 0; i < data.length; i++) {
	data[i].id;
	console.log(data[i].prix);
	$("#container .row").append(` 
		

      <div class="col-sm-4" >
        <div class="thumbnail"
       style="border-style: groove;
        border-color: #A4A4A4;
        padding: 10px;
        margin: 10px;
        border-size:1px;">
            <h1 style="
            text-transform:uppercase;
            font-style:italic;
            color:black;
            "
            >${data[i].nom}</h1>
            <center><img  src="${data[i].img}" width="220" height="220"></center>
           
            <h4
                style="text-transform: uppercase;"
            >description</h4>
            <p 
            >${data[i].description} </p>
            
      
        </div>
      
    </div>

	`);
	

}

 } );

