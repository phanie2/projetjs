$(document).ready(function(){


var objet1= {
id : 1,
nom:"bissap",

description : "jus d'hibiscuss communement appele bissap",
img : "images/bisssap.jpg"

};
var objet2 ={
id : 2,
nom:"gnamakoudji",

description : "jus de gengimbre communement appele gnamakoudji",
img : "images/gnamakou.jpg"

};
var objet3 ={
id : 3,
nom:"jus de mangue",

description : "jus de mangue pure",
img : "images/mangue.jpg"

};

var objet4 = {
id : 4,
nom:"jus de tamarin",

description : "du jus de tamarin communement appele tomydji",
img : "images/tamarin.jpg"

};

var objet5= {
id : 5,

description : "du jus d'ananas",
img : "images/ananas.jpeg"

};
var objet6 ={
id : 6,
nom:"jus d'orange",

description : "du jus d'orange pure",
img : "images/orange.jpg"

};
var objet7 ={
id :7 ,
nom:"jus de citron",

description : "du jus de citron pure",
img : "images/citron.jpg"

};

var data=[objet1,objet2,objet3,objet4,objet5,objet6,objet7] ;
console.log(data);

for (var i = 0; i < data.length; i++) {
	data[i].id;
	console.log(data[i].prix);
	$("#container2 .row").append(` 
		

      <div class="col-sm-4" >
      <div class="thumbnail" 
      style="border-style: groove;
      border-color: #A4A4A4;
      padding: 10px;
      margin: 10px;
      border-size:1px;">
            <h1 style="
            text-transform:uppercase;
            font-style:italic;
            color:black;
            ">${data[i].nom}</h1>
           <center> <img  src="${data[i].img}" width="220" height="220"></center>
        
            <h4  style="text-transform: uppercase;"
            >description</h4>
            <p
            style="
            color:white; font-size:15px;">${data[i].description} </p>
            
         
        </div>
      
    </div>

	`);
	

}
} );
